# 00_setup.R -----------------------------------------------------------------
# Package installation, project paths, and utility functions.

required_pkgs <- c(
  'tidyverse', 'data.table', 'readxl', 'janitor', 'httr2', 'jsonlite',
  'tidycensus', 'tigris', 'sf', 'quarto', 'rmarkdown', 'knitr', 'DT',
  'scales', 'glue', 'yaml', 'fs', 'stringr', 'Matrix', 'cli', 'ggrepel', 'png'
)

# Packages used to create editable DrawingML figures inside Excel. These are
# installed/updated before any graphics packages are loaded because ragg and
# other graphics packages can load systemfonts. On Windows, an already-loaded
# systemfonts DLL cannot be replaced during the same R session.
editable_excel_pkgs <- c('systemfonts', 'gdtools', 'officer', 'rvg', 'openxlsx2')
editable_excel_min_versions <- c(
  systemfonts = '1.3.1',
  gdtools = '0.5.0',
  rvg = '0.4.1',
  openxlsx2 = '1.26.0'
)

# R 4.4/Puppy Cup compatibility note:
# Arrow and DuckDB are excellent high-performance storage/database packages,
# but they can be difficult to install on older R minor versions or locked-down
# Windows/Positron environments. They are now optional. If arrow is installed,
# the workflow writes Parquet just as before. If arrow is unavailable, the same
# atlas data are written/read as compressed RDS and CSV.GZ fallback files.
optional_storage_pkgs <- c('arrow', 'duckdb')

# Optional analysis packages are not required by the pipeline. Some helper
# packages are unavailable on certain R releases, so we do not install them
# automatically in run_all.R.
optional_pkgs <- c('grf', 'fixest', 'modelsummary', 'ragg', optional_storage_pkgs)

# R 4.4.0 / Positron compatibility ---------------------------------------
# R 4.4.0 is the "Puppy Cup" release. The workflow is intentionally kept
# compatible with R >= 4.4.0 while preserving the same analysis, figures,
# HTML reports, and PDF outputs produced by the R 4.6.x run.
minimum_r_version <- package_version('4.4.0')

atlas_package_library <- function() {
  override <- Sys.getenv('IA_ATLAS_R_LIB', unset = '')
  if (nzchar(override)) return(normalizePath(path.expand(override), winslash = '/', mustWork = FALSE))

  r_tag <- paste0('R-', R.version[['major']], '.', strsplit(R.version[['minor']], '.', fixed = TRUE)[[1L]][1L])
  if (.Platform$OS.type == 'windows') {
    base <- Sys.getenv('LOCALAPPDATA', unset = '')
    if (!nzchar(base)) base <- file.path(path.expand('~'), 'AppData', 'Local')
    return(normalizePath(file.path(base, 'IowaAIWorkforceAtlas', 'library', r_tag), winslash = '/', mustWork = FALSE))
  }
  normalizePath(file.path(path.expand('~'), '.local', 'share', 'IowaAIWorkforceAtlas', 'library', r_tag), winslash = '/', mustWork = FALSE)
}

activate_atlas_package_library <- function() {
  lib <- atlas_package_library()
  dir.create(lib, recursive = TRUE, showWarnings = FALSE)
  .libPaths(unique(c(lib, .libPaths())))
  options(ia_atlas_package_library = lib)
  invisible(lib)
}

setup_repos <- function() {
  activate_atlas_package_library()
  # Posit Package Manager generally provides the most reliable macOS/Windows/
  # Linux binaries for Positron users. Users can override this with
  # IA_ATLAS_CRAN_REPO, e.g. to a local CRAN mirror or a Posit snapshot.
  repo <- Sys.getenv('IA_ATLAS_CRAN_REPO', unset = '')
  if (!nzchar(repo)) repo <- 'https://packagemanager.posit.co/cran/latest'

  repos <- getOption('repos')
  current <- tryCatch(repos[['CRAN']], error = function(e) NA_character_)
  if (is.null(repos) || is.na(current) || identical(current, '@CRAN@') || !nzchar(current)) {
    options(repos = c(CRAN = repo))
  }

  # libcurl is available in standard R builds on macOS/Windows and works
  # well inside Positron for BLS/Census/O*NET downloads.
  options(download.file.method = 'libcurl')
  options(tigris_use_cache = TRUE)

  # On Windows and macOS, prefer binary packages. This avoids Rtools/source
  # compilation failures for heavy packages in R 4.4.x environments.
  if (.Platform$OS.type == 'windows' || identical(Sys.info()[['sysname']], 'Darwin')) {
    options(pkgType = 'binary')
  }
  invisible(getOption('repos'))
}

check_r_compatibility <- function(strict = FALSE) {
  rv <- getRversion()
  codename <- R.version[['nickname']] %||% ''
  msg <- sprintf('Detected R %s%s.', as.character(rv), if (nzchar(codename)) paste0(' (', codename, ')') else '')
  if (!isTRUE(getOption('ia_atlas_r_version_reported', FALSE))) {
    message(msg)
    options(ia_atlas_r_version_reported = TRUE)
  }
  if (rv < minimum_r_version) {
    txt <- sprintf('This project targets R >= %s. Detected R %s. Upgrade R or use the current R 4.4.0 Puppy Cup compatibility package.',
                   as.character(minimum_r_version), as.character(rv))
    if (isTRUE(strict)) stop(txt, call. = FALSE) else warning(txt, call. = FALSE)
  }
  invisible(TRUE)
}

.install_one_package <- function(pkg, optional = FALSE) {
  msg <- if (optional) 'optional' else 'required'
  message(sprintf('Installing %s package: %s', msg, pkg))
  cores <- parallel::detectCores(logical = TRUE)
  if (is.na(cores) || cores < 2L) cores <- 2L
  ncpus <- max(1L, cores - 1L)

  # First try the configured repository, normally Posit Package Manager.
  ok <- tryCatch({
    utils::install.packages(pkg, lib = .libPaths()[1L], dependencies = c('Depends', 'Imports', 'LinkingTo'), quiet = TRUE, Ncpus = ncpus, type = getOption('pkgType', 'binary'))
    TRUE
  }, error = function(e) {
    warning(sprintf('Primary install failed for %s: %s', pkg, conditionMessage(e)), call. = FALSE)
    FALSE
  })

  # If a user had a stale/custom repo configured, retry once against CRAN.
  if (!ok) {
    old_repos <- getOption('repos')
    on.exit(options(repos = old_repos), add = TRUE)
    options(repos = c(CRAN = 'https://cloud.r-project.org'))
    ok <- tryCatch({
      utils::install.packages(pkg, lib = .libPaths()[1L], dependencies = c('Depends', 'Imports', 'LinkingTo'), quiet = TRUE, Ncpus = ncpus, type = getOption('pkgType', 'binary'))
      TRUE
    }, error = function(e) {
      warning(sprintf('Fallback CRAN install failed for %s: %s', pkg, conditionMessage(e)), call. = FALSE)
      FALSE
    })
  }

  if (!optional && (!ok || !requireNamespace(pkg, quietly = TRUE))) {
    stop('Required package failed to install or load namespace: ', pkg, call. = FALSE)
  }
  invisible(ok)
}

installed_package_version <- function(pkg) {
  tryCatch(utils::packageVersion(pkg), error = function(e) package_version('0.0.0'))
}

package_version_is_current <- function(pkg, minimum = NULL) {
  installed <- pkg %in% rownames(utils::installed.packages())
  if (!installed) return(FALSE)
  if (is.null(minimum) || is.na(minimum) || !nzchar(as.character(minimum))) return(TRUE)
  isTRUE(installed_package_version(pkg) >= package_version(as.character(minimum)))
}

ensure_editable_excel_toolchain <- function(install_missing = TRUE) {
  setup_repos()

  # If an old systemfonts namespace is already loaded, R cannot swap the DLL in
  # place. A clean session is the only reliable remedy. In a normal run_all.R
  # invocation this check occurs before ragg/ggtext/other graphics packages load.
  if ('systemfonts' %in% loadedNamespaces()) {
    loaded_version <- tryCatch(package_version(getNamespaceVersion('systemfonts')), error = function(e) package_version('0.0.0'))
    if (loaded_version < package_version(editable_excel_min_versions[['systemfonts']])) {
      stop(
        'An older systemfonts namespace (', as.character(loaded_version), ') is already loaded. ',
        'Restart the R session, then run source("R/run_all.R") once. The project now installs the editable-Excel toolchain before graphics packages load.',
        call. = FALSE
      )
    }
  }

  for (pkg in editable_excel_pkgs) {
    minimum <- unname(editable_excel_min_versions[pkg])
    if (!length(minimum) || is.na(minimum)) minimum <- NULL
    needs_install <- !package_version_is_current(pkg, minimum)
    if (needs_install && isTRUE(install_missing)) {
      .install_one_package(pkg, optional = FALSE)
    }
    if (!package_version_is_current(pkg, minimum)) {
      found <- as.character(installed_package_version(pkg))
      requirement <- if (is.null(minimum) || is.na(minimum)) '' else paste0(' >= ', minimum)
      stop(
        'Editable Excel dependency is unavailable or too old: ', pkg, requirement,
        ' (found ', found, '). Restart R and rerun; packages are installed to ',
        getOption('ia_atlas_package_library', .libPaths()[1L]), '.',
        call. = FALSE
      )
    }
  }
  invisible(TRUE)
}

install_if_missing <- function(pkgs = required_pkgs, optional = FALSE) {
  setup_repos()
  installed <- rownames(utils::installed.packages())
  missing <- setdiff(pkgs, installed)
  if (!length(missing)) return(invisible(TRUE))
  for (pkg in missing) .install_one_package(pkg, optional = optional)
  invisible(TRUE)
}

setup_packages <- function(install_optional = TRUE, strict_r = FALSE) {
  setup_repos()
  check_r_compatibility(strict = strict_r)

  # Install/update the Excel DrawingML stack before any graphics namespace can
  # lock an older systemfonts DLL on Windows/Positron.
  ensure_editable_excel_toolchain(install_missing = TRUE)
  install_if_missing(required_pkgs, optional = FALSE)

  failed <- character()
  for (pkg in required_pkgs) {
    ok <- suppressWarnings(suppressPackageStartupMessages(require(pkg, character.only = TRUE)))
    if (!ok) failed <- c(failed, pkg)
  }
  if (length(failed)) stop('Required packages could not be loaded: ', paste(failed, collapse = ', '), call. = FALSE)

  if (install_optional) install_if_missing(optional_pkgs, optional = TRUE)
  invisible(TRUE)
}

project_root <- function() {
  # Works from project root, R/ scripts, or a rendered document.
  here <- getwd()
  candidates <- c(here, dirname(here), normalizePath(file.path(here, '..'), mustWork = FALSE))
  for (cand in unique(candidates)) {
    if (file.exists(file.path(cand, 'config.yml')) && dir.exists(file.path(cand, 'R'))) {
      return(normalizePath(cand, winslash = '/', mustWork = TRUE))
    }
  }
  normalizePath(here, winslash = '/', mustWork = TRUE)
}

paths <- function() {
  root <- project_root()
  x <- list(
    root = root,
    R = file.path(root, 'R'),
    inputs = file.path(root, 'inputs'),
    raw = file.path(root, 'data_raw'),
    processed = file.path(root, 'data_processed'),
    outputs = file.path(root, 'outputs'),
    figures = file.path(root, 'figures'),
    logs = file.path(root, 'logs')
  )
  invisible(lapply(x, fs::dir_create))
  x
}

load_config <- function() {
  p <- paths()
  cfg_path <- file.path(p$root, 'config.yml')
  if (!file.exists(cfg_path)) stop('Missing config.yml at project root.', call. = FALSE)
  yaml::read_yaml(cfg_path)
}

clean_soc <- function(x) {
  x <- as.character(x)
  x <- stringr::str_trim(x)
  x <- stringr::str_replace_all(x, '\\.', '-')
  x <- stringr::str_replace(x, '\\-00$', '')
  x <- stringr::str_replace(x, '\\.[0-9]+$', '')
  # Convert 111011 or 11-1011.00 to 11-1011.
  x <- dplyr::case_when(
    stringr::str_detect(x, '^\\d{6}$') ~ paste0(substr(x, 1, 2), '-', substr(x, 3, 6)),
    stringr::str_detect(x, '^\\d{2}-\\d{4}') ~ stringr::str_extract(x, '^\\d{2}-\\d{4}'),
    TRUE ~ x
  )
  x
}

clean_fips <- function(x, width = 5) {
  stringr::str_pad(as.character(x), width = width, pad = '0')
}

rescale01 <- function(x) {
  x <- suppressWarnings(as.numeric(x))
  if (all(is.na(x))) return(rep(NA_real_, length(x)))
  rng <- range(x, na.rm = TRUE)
  if (!is.finite(rng[1]) || !is.finite(rng[2]) || abs(diff(rng)) < .Machine$double.eps) {
    return(rep(0.5, length(x)))
  }
  (x - rng[1]) / diff(rng)
}

winsor <- function(x, probs = c(0.01, 0.99)) {
  qs <- stats::quantile(x, probs = probs, na.rm = TRUE, names = FALSE)
  pmin(pmax(x, qs[1]), qs[2])
}

atlas_user_agent <- function() {
  ua <- Sys.getenv('IA_ATLAS_USER_AGENT')
  if (!nzchar(ua)) {
    ua <- 'iowa-ai-workforce-atlas/1.2 research-script https://www.bls.gov/oes/'
  }
  ua
}

is_probably_html_error <- function(path) {
  if (!file.exists(path) || file.info(path)$size == 0) return(TRUE)
  ext <- tolower(tools::file_ext(path))
  if (ext %in% c('html', 'htm')) return(TRUE)
  bytes <- tryCatch(readBin(path, what = 'raw', n = min(512, file.info(path)$size)), error = function(e) raw())
  if (!length(bytes)) return(TRUE)
  txt <- tryCatch(tolower(rawToChar(bytes, multiple = FALSE)), error = function(e) '')
  grepl('<html|forbidden|access denied|not found|request blocked', txt)
}


`%||%` <- function(x, y) {
  if (is.null(x) || length(x) == 0 || all(is.na(x))) y else x
}

download_if_needed <- function(url, dest, refresh = FALSE, mode = 'wb') {
  fs::dir_create(dirname(dest))
  if (file.exists(dest) && !refresh && file.info(dest)$size > 0 && !is_probably_html_error(dest)) return(dest)
  if (file.exists(dest)) unlink(dest)

  message('Downloading: ', url)
  ok <- FALSE
  last_error <- NULL

  # BLS occasionally rejects the default R downloader.  httr2 with an explicit
  # user agent and browser-like Accept headers is more reliable and also works
  # for Census/LEHD text files.
  if (requireNamespace('httr2', quietly = TRUE)) {
    ok <- tryCatch({
      req <- httr2::request(url) |>
        httr2::req_user_agent(atlas_user_agent()) |>
        httr2::req_headers(
          Accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,application/zip,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/plain,*/*;q=0.8',
          `Accept-Language` = 'en-US,en;q=0.9'
        ) |>
        httr2::req_timeout(600) |>
        httr2::req_retry(max_tries = 3)
      httr2::req_perform(req, path = dest)
      TRUE
    }, error = function(e) {
      last_error <<- conditionMessage(e)
      FALSE
    })
  }

  if (!ok) {
    ok <- tryCatch({
      extra <- paste0('-A "', atlas_user_agent(), '"')
      utils::download.file(url, destfile = dest, mode = mode, quiet = TRUE,
                           method = 'libcurl', extra = extra)
      TRUE
    }, error = function(e) {
      last_error <<- conditionMessage(e)
      FALSE
    })
  }

  if (!ok || !file.exists(dest) || file.info(dest)$size == 0 || is_probably_html_error(dest)) {
    if (file.exists(dest)) unlink(dest)
    msg <- if (nzchar(last_error %||% '')) paste0(': ', last_error) else ''
    stop('Could not download ', url, msg, call. = FALSE)
  }
  dest
}

try_download <- function(urls, dest_dir, refresh = FALSE) {
  fs::dir_create(dest_dir)
  last_error <- NULL
  for (u in urls) {
    dest <- file.path(dest_dir, basename(u))
    ans <- tryCatch(download_if_needed(u, dest, refresh = refresh), error = function(e) {
      last_error <<- conditionMessage(e)
      NULL
    })
    if (!is.null(ans)) return(ans)
  }
  stop('All download attempts failed. Last error: ', last_error, call. = FALSE)
}

read_delim_auto <- function(path) {
  data.table::fread(path, data.table = FALSE, showProgress = FALSE) |>
    janitor::clean_names()
}

normalize_names <- function(x) janitor::make_clean_names(names(x))

first_existing <- function(...) {
  vals <- unlist(list(...), use.names = FALSE)
  vals[file.exists(vals)][1]
}

write_log <- function(text, file = 'run.log') {
  p <- paths()
  cat(format(Sys.time()), ' - ', text, '\n', file = file.path(p$logs, file), append = TRUE)
}

compat_table_paths <- function(base_name, dir = NULL) {
  if (is.null(dir)) dir <- paths()$processed
  list(
    parquet = file.path(dir, paste0(base_name, '.parquet')),
    rds = file.path(dir, paste0(base_name, '.rds')),
    csv_gz = file.path(dir, paste0(base_name, '.csv.gz')),
    csv = file.path(dir, paste0(base_name, '.csv'))
  )
}

compat_table_exists <- function(base_name, dir = NULL) {
  pp <- compat_table_paths(base_name, dir)
  any(vapply(pp, file.exists, logical(1)))
}

write_compat_table <- function(x, base_name, dir = NULL, write_csv_gz = TRUE, write_parquet = TRUE) {
  if (is.null(dir)) dir <- paths()$processed
  fs::dir_create(dir)
  pp <- compat_table_paths(base_name, dir)

  # Always write an RDS copy. This is base R, fast, and preserves column types.
  saveRDS(x, pp$rds, compress = 'xz')

  # Always write a CSV.GZ copy for transparency and users without arrow.
  if (isTRUE(write_csv_gz)) {
    readr::write_csv(x, pp$csv_gz)
  }

  parquet_status <- 'not attempted'
  if (isTRUE(write_parquet) && requireNamespace('arrow', quietly = TRUE)) {
    parquet_status <- tryCatch({
      arrow::write_parquet(x, pp$parquet)
      'written'
    }, error = function(e) {
      warning('Arrow is installed but Parquet write failed for ', base_name, ': ', conditionMessage(e),
              '. RDS/CSV.GZ fallbacks were written.', call. = FALSE)
      if (file.exists(pp$parquet)) unlink(pp$parquet)
      'failed'
    })
  } else if (isTRUE(write_parquet)) {
    parquet_status <- 'skipped: arrow not installed'
    if (file.exists(pp$parquet)) unlink(pp$parquet)
  }

  invisible(c(pp, list(parquet_status = parquet_status)))
}

read_compat_table <- function(base_name, dir = NULL) {
  if (is.null(dir)) dir <- paths()$processed
  pp <- compat_table_paths(base_name, dir)
  if (file.exists(pp$parquet) && requireNamespace('arrow', quietly = TRUE)) {
    return(arrow::read_parquet(pp$parquet) |> dplyr::as_tibble())
  }
  if (file.exists(pp$rds)) {
    return(readRDS(pp$rds) |> dplyr::as_tibble())
  }
  if (file.exists(pp$csv_gz)) {
    return(readr::read_csv(pp$csv_gz, show_col_types = FALSE))
  }
  if (file.exists(pp$csv)) {
    return(readr::read_csv(pp$csv, show_col_types = FALSE))
  }
  stop('Could not find ', base_name, ' in Parquet, RDS, CSV.GZ, or CSV form under ', dir, call. = FALSE)
}

# Backward-compatible helper used by older scripts. It now reads the best
# available compatible storage format instead of requiring arrow.
safe_read_parquet <- function(path) {
  if (is.null(path) || !nzchar(path)) return(NULL)
  base_name <- tools::file_path_sans_ext(basename(path))
  dir <- dirname(path)
  if (!compat_table_exists(base_name, dir)) return(NULL)
  read_compat_table(base_name, dir)
}
