# 10_iowa_report_style.R ----------------------------------------------------
# Shared style guide for Iowa AI Workforce Atlas reports, charts, tables, and
# PDF figure packets. This file intentionally avoids non-base dependencies
# beyond ggplot2/scales when those functions are called.

atlas_brand <- function() {
  list(
    blue  = '#1C5DBA', # RGB 28, 93, 186
    teal  = '#00808D', # RGB 0, 128, 141
    gold  = '#E0A624', # RGB 224, 166, 36
    green = '#C6D667', # RGB 198, 214, 103
    red   = '#B32A2D', # RGB 179, 42, 45
    black = '#000000',
    grey  = '#7F7F7F',
    light_grey = '#E6E6E6'
  )
}

atlas_font_family <- function() {
  # Requested report font. For HTML and PNG output this should resolve to
  # Arial on Windows/macOS and fall back through the report CSS to Helvetica/sans.
  fam <- Sys.getenv('IA_ATLAS_FONT_FAMILY', unset = 'Arial')
  if (!nzchar(fam)) fam <- 'Arial'
  fam
}

atlas_pdf_font_family <- function() {
  # The base R pdf() device uses a PostScript font database and can fail with
  # `invalid font type` for Arial on locked-down Windows/Positron installs.
  # Use a safe device font for R-generated fallback PDFs while the HTML/PDF
  # reports themselves still request Arial through CSS.
  fam <- Sys.getenv('IA_ATLAS_PDF_FONT_FAMILY', unset = '')
  if (nzchar(fam)) return(fam)
  if (.Platform$OS.type == 'windows') return('sans')
  'Arial'
}

atlas_axis_percent <- function(accuracy = 1) {
  scales::label_percent(accuracy = accuracy)
}

atlas_axis_number <- function(accuracy = 1) {
  scales::label_number(big.mark = ',', accuracy = accuracy)
}

atlas_jobs_number <- function(accuracy = 1) {
  scales::label_number(big.mark = ',', accuracy = accuracy)
}

atlas_jobs_short <- function(accuracy = 0.1) {
  scales::label_number(scale_cut = scales::cut_short_scale(), accuracy = accuracy)
}

atlas_base_theme <- function(base_size = 10, strip_titles = TRUE) {
  b <- atlas_brand()
  ggplot2::theme_minimal(base_family = atlas_font_family(), base_size = base_size) +
    ggplot2::theme(
      text = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      axis.title = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      axis.text = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      legend.title = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      legend.text = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      strip.text = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      plot.title = if (isTRUE(strip_titles)) ggplot2::element_blank() else ggplot2::element_text(family = atlas_font_family(), size = 12, colour = b$black, face = 'bold', hjust = 0.5),
      plot.subtitle = if (isTRUE(strip_titles)) ggplot2::element_blank() else ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      plot.caption = ggplot2::element_blank(),
      plot.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
      panel.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
      legend.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
      legend.box.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
      panel.grid.minor = ggplot2::element_blank()
    )
}

atlas_void_theme <- function(base_size = 10, strip_titles = TRUE) {
  b <- atlas_brand()
  ggplot2::theme_void(base_family = atlas_font_family(), base_size = base_size) +
    ggplot2::theme(
      text = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      axis.title = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      axis.text = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      legend.title = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      legend.text = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      plot.title = if (isTRUE(strip_titles)) ggplot2::element_blank() else ggplot2::element_text(family = atlas_font_family(), size = 12, colour = b$black, face = 'bold', hjust = 0.5),
      plot.subtitle = if (isTRUE(strip_titles)) ggplot2::element_blank() else ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
      plot.caption = ggplot2::element_blank(),
      plot.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
      panel.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
      legend.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
      legend.box.background = ggplot2::element_rect(fill = 'transparent', colour = NA)
    )
}

atlas_export_theme <- function() {
  b <- atlas_brand()
  ggplot2::theme(
    text = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
    axis.title = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
    axis.text = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
    legend.title = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
    legend.text = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
    strip.text = ggplot2::element_text(family = atlas_font_family(), size = 10, colour = b$black, face = 'plain'),
    plot.title = ggplot2::element_blank(),
    plot.subtitle = ggplot2::element_blank(),
    plot.caption = ggplot2::element_blank(),
    plot.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
    panel.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
    legend.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
    legend.box.background = ggplot2::element_rect(fill = 'transparent', colour = NA)
  )
}

atlas_apply_export_theme <- function(plot) {
  thm <- atlas_export_theme()

  # Patchwork objects are composed from already-themed transparent ggplots.
  # Returning the object unchanged avoids two R 4.4 compatibility problems:
  # older patchwork builds may not dispatch `&(patchwork, theme)`, and some
  # builds warn that annotation$theme is not a valid theme. The output device
  # and alpha validation still enforce a transparent outer canvas.
  if (inherits(plot, 'patchwork')) return(plot)

  tryCatch(plot + thm, error = function(e) plot)
}

atlas_png_alpha_status <- function(path) {
  out <- list(
    path = path,
    readable = FALSE,
    channels = NA_integer_,
    has_alpha = FALSE,
    transparent_pixels = 0,
    total_pixels = NA_real_
  )
  if (!file.exists(path) || !requireNamespace('png', quietly = TRUE)) return(out)

  img <- tryCatch(png::readPNG(path), error = function(e) NULL)
  if (is.null(img)) return(out)
  dims <- dim(img)
  channels <- if (length(dims) >= 3L) dims[[3L]] else 1L
  has_alpha <- identical(as.integer(channels), 4L)
  transparent_pixels <- if (has_alpha) sum(img[, , 4L] < (1 - 1e-8), na.rm = TRUE) else 0

  out$readable <- TRUE
  out$channels <- as.integer(channels)
  out$has_alpha <- isTRUE(has_alpha)
  out$transparent_pixels <- as.double(transparent_pixels)
  out$total_pixels <- as.double(dims[[1L]]) * as.double(dims[[2L]])
  out
}

atlas_force_transparent_alpha <- function(path, tolerance = 3 / 255) {
  if (!file.exists(path) || !requireNamespace('png', quietly = TRUE)) return(FALSE)
  img <- tryCatch(png::readPNG(path), error = function(e) NULL)
  if (is.null(img)) return(FALSE)

  dims <- dim(img)
  if (length(dims) < 3L || dims[[3L]] < 3L) return(FALSE)
  h <- dims[[1L]]
  w <- dims[[2L]]
  rgb <- img[, , 1:3, drop = FALSE]
  alpha <- if (dims[[3L]] >= 4L) img[, , 4L] else matrix(1, nrow = h, ncol = w)

  # Use the four corners to identify the canvas color. This repair is used when
  # a graphics device produced an RGB PNG despite a transparent request. It is
  # mandatory for Figure 01 and the four core report figures, where pure white
  # is the canvas/boundary color rather than a substantive data category.
  corners <- rbind(
    rgb[1L, 1L, ], rgb[1L, w, ], rgb[h, 1L, ], rgb[h, w, ]
  )
  bg <- colMeans(corners)
  if (max(abs(sweep(corners, 2L, bg, '-'))) > (4 * tolerance)) return(FALSE)
  if (mean(bg) < 0.90) return(FALSE)

  bg_mask <- abs(rgb[, , 1L] - bg[[1L]]) <= tolerance &
    abs(rgb[, , 2L] - bg[[2L]]) <= tolerance &
    abs(rgb[, , 3L] - bg[[3L]]) <= tolerance
  alpha[bg_mask] <- 0

  rgba <- array(0, dim = c(h, w, 4L))
  rgba[, , 1:3] <- rgb
  rgba[, , 4L] <- alpha
  tryCatch({
    png::writePNG(rgba, target = path)
    st <- atlas_png_alpha_status(path)
    isTRUE(st$has_alpha) && st$transparent_pixels > 0
  }, error = function(e) FALSE)
}

atlas_save_transparent_png <- function(plot, filename, width, height, dpi = 320,
                                       force_alpha_repair = FALSE) {
  dir.create(dirname(filename), recursive = TRUE, showWarnings = FALSE)
  plot <- atlas_apply_export_theme(plot)

  opened <- FALSE
  render_error <- NULL
  tryCatch({
    if (requireNamespace('ragg', quietly = TRUE)) {
      ragg::agg_png(
        filename = filename,
        width = width,
        height = height,
        units = 'in',
        res = dpi,
        background = 'transparent'
      )
    } else if (isTRUE(capabilities('cairo'))) {
      grDevices::png(
        filename = filename,
        width = width,
        height = height,
        units = 'in',
        res = dpi,
        bg = 'transparent',
        type = 'cairo-png'
      )
    } else {
      grDevices::png(
        filename = filename,
        width = width,
        height = height,
        units = 'in',
        res = dpi,
        bg = 'transparent'
      )
    }
    opened <- TRUE
    print(plot)
  }, error = function(e) {
    render_error <<- e
  }, finally = {
    if (isTRUE(opened)) try(grDevices::dev.off(), silent = TRUE)
  })

  if (!is.null(render_error) || !file.exists(filename) || file.info(filename)$size <= 0) {
    ggplot2::ggsave(
      filename = filename,
      plot = plot,
      width = width,
      height = height,
      dpi = dpi,
      bg = 'transparent'
    )
  }

  status <- atlas_png_alpha_status(filename)
  if (isTRUE(force_alpha_repair) && (!isTRUE(status$has_alpha) || status$transparent_pixels <= 0)) {
    atlas_force_transparent_alpha(filename)
    status <- atlas_png_alpha_status(filename)
  }

  if (isTRUE(force_alpha_repair) && (!isTRUE(status$has_alpha) || status$transparent_pixels <= 0)) {
    stop(
      'Transparent PNG validation failed for ', basename(filename),
      '. The file does not contain transparent pixels after rendering and repair.',
      call. = FALSE
    )
  }

  attr(filename, 'alpha_status') <- status
  invisible(filename)
}

atlas_color_scale_continuous <- function(..., labels = NULL) {
  b <- atlas_brand()
  if (is.null(labels)) labels <- scales::label_number(big.mark = ',', accuracy = 1)
  ggplot2::scale_fill_gradientn(
    colours = c(b$green, b$blue, b$red),
    labels = labels,
    ...
  )
}

atlas_transition_palette <- function() {
  b <- atlas_brand()
  c(
    'Protect and redesign' = b$red,
    'Upgrade through AI-complementary training' = b$gold,
    'Scale pro-worker AI opportunity' = b$blue,
    'Monitor' = b$grey
  )
}

atlas_channel_palette <- function() {
  b <- atlas_brand()
  c(
    'Automation exposure' = b$red,
    'Augmentation potential' = b$blue,
    'Expertise-leveling potential' = b$green,
    'New-task opportunity' = b$gold,
    'Pro-worker opportunity' = b$teal
  )
}
