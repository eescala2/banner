# 09_positron_r44_check.R ---------------------------------------------------
# Optional diagnostic for Positron + R 4.4.0 ("Puppy Cup") environments.
# This does not change atlas outputs. It simply reports whether the local
# environment has the expected R version, packages, Quarto, and Chrome/Chromium
# PDF-printing support.

.local_project_root_check <- function() {
  here <- normalizePath(getwd(), winslash = '/', mustWork = TRUE)
  candidates <- unique(c(
    here,
    dirname(here),
    normalizePath(file.path(here, '..'), winslash = '/', mustWork = FALSE),
    normalizePath(file.path(here, '../..'), winslash = '/', mustWork = FALSE)
  ))
  for (cand in candidates) {
    if (file.exists(file.path(cand, 'config.yml')) && dir.exists(file.path(cand, 'R'))) {
      return(normalizePath(cand, winslash = '/', mustWork = TRUE))
    }
  }
  here
}

root0 <- .local_project_root_check()
source(file.path(root0, 'R', '00_setup.R'))

find_chrome_for_pdf <- function() {
  env <- Sys.getenv('PAGEDOWN_CHROME', unset = '')
  if (nzchar(env) && file.exists(env)) return(env)
  candidates <- c(
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    Sys.which('google-chrome'), Sys.which('chromium'), Sys.which('chromium-browser'), Sys.which('chrome')
  )
  candidates <- unique(candidates[nzchar(candidates)])
  candidates[file.exists(candidates)][1] %||% NA_character_
}

positron_r44_environment_check <- function(write_outputs = TRUE) {
  setup_repos()
  p <- paths()
  pkgs <- unique(c(required_pkgs, 'patchwork', 'ggforce', 'ggridges', 'ggalluvial',
                   'treemapify', 'ggtext', 'viridis', 'htmltools', 'png', 'pagedown',
                   optional_storage_pkgs, editable_excel_pkgs))
  package_rows <- data.frame(
    check = paste0('package:', pkgs),
    value = vapply(pkgs, function(pkg) {
      if (requireNamespace(pkg, quietly = TRUE)) as.character(utils::packageVersion(pkg)) else 'not installed'
    }, character(1)),
    status = vapply(pkgs, function(pkg) {
      if (requireNamespace(pkg, quietly = TRUE)) 'ok' else 'missing'
    }, character(1)),
    stringsAsFactors = FALSE
  )
  quarto_available <- if (requireNamespace('quarto', quietly = TRUE) && 'quarto_available' %in% getNamespaceExports('quarto')) {
    isTRUE(quarto::quarto_available())
  } else {
    nzchar(Sys.which('quarto'))
  }
  rows <- data.frame(
    check = c('R version', 'R nickname', 'minimum target R', 'repository', 'Atlas package library', 'Quarto CLI available', 'Chrome/Chromium for PDF'),
    value = c(as.character(getRversion()), R.version[['nickname']] %||% '', '4.4.0', getOption('repos')[['CRAN']] %||% '', getOption('ia_atlas_package_library', .libPaths()[1L]), as.character(quarto_available), find_chrome_for_pdf() %||% ''),
    status = c(if (getRversion() >= package_version('4.4.0')) 'ok' else 'upgrade R', 'info', 'info', 'info', 'info', if (quarto_available) 'ok' else 'missing', if (!is.na(find_chrome_for_pdf())) 'ok' else 'optional missing'),
    stringsAsFactors = FALSE
  )
  out <- rbind(rows, package_rows)
  if (isTRUE(write_outputs)) {
    utils::write.csv(out, file.path(p$outputs, 'positron_r44_environment_check.csv'), row.names = FALSE)
    message('Wrote environment check: ', file.path(p$outputs, 'positron_r44_environment_check.csv'))
  }
  out
}
