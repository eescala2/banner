# 99_make_editable_excel_only.R ---------------------------------------------
# Fast recovery path after the atlas figures/reports have already been built.
# IMPORTANT on Windows: start a fresh R session before running this script if a
# previous run reported that systemfonts was already loaded or could not be
# replaced.

.find_root_excel_only <- function() {
  here <- normalizePath(getwd(), winslash = '/', mustWork = TRUE)
  candidates <- unique(c(
    here,
    dirname(here),
    normalizePath(file.path(here, '..'), winslash = '/', mustWork = FALSE),
    normalizePath(file.path(here, '../..'), winslash = '/', mustWork = FALSE)
  ))
  for (cand in candidates) {
    if (file.exists(file.path(cand, 'config.yml')) && dir.exists(file.path(cand, 'R'))) {
      return(normalizePath(cand, winslash = '/', mustWork = TRUE))
    }
  }
  stop('Could not locate the project root.', call. = FALSE)
}

.root <- .find_root_excel_only()
.old_wd <- getwd()
on.exit(setwd(.old_wd), add = TRUE)
setwd(.root)

source(file.path('R', '00_setup.R'))
setup_packages(install_optional = FALSE)
source(file.path('R', '12_excel_editable_figures.R'))

make_editable_excel_figures(
  install_missing = TRUE,
  build_if_missing = FALSE,
  refresh = FALSE,
  stop_on_error = TRUE
)

message('Editable Excel workbook created at outputs/iowa_ai_workforce_atlas_editable_figures.xlsx')
