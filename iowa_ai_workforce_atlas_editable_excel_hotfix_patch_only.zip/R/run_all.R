# R/run_all.R ---------------------------------------------------------------
# Run the complete Iowa AI Workforce Atlas workflow from Positron, RStudio,
# or a terminal. Compatible with R 4.4.0 ("Puppy Cup") and newer R releases.

.local_project_root_runall <- function() {
  here <- normalizePath(getwd(), winslash = '/', mustWork = TRUE)
  script_dir <- tryCatch({
    frames <- sys.frames()
    ofiles <- vapply(frames, function(x) {
      val <- x$ofile
      if (is.null(val)) NA_character_ else as.character(val)
    }, character(1))
    ofiles <- stats::na.omit(ofiles)
    if (length(ofiles)) normalizePath(dirname(ofiles[[length(ofiles)]]), winslash = '/', mustWork = FALSE) else NA_character_
  }, error = function(e) NA_character_)
  candidates <- unique(stats::na.omit(c(
    here,
    dirname(here),
    normalizePath(file.path(here, '..'), winslash = '/', mustWork = FALSE),
    normalizePath(file.path(here, '../..'), winslash = '/', mustWork = FALSE),
    script_dir,
    normalizePath(file.path(script_dir, '..'), winslash = '/', mustWork = FALSE),
    normalizePath(file.path(script_dir, '../..'), winslash = '/', mustWork = FALSE)
  )))
  for (cand in candidates) {
    if (file.exists(file.path(cand, 'config.yml')) && dir.exists(file.path(cand, 'R'))) {
      return(normalizePath(cand, winslash = '/', mustWork = TRUE))
    }
  }
  stop('Could not locate the Iowa AI Workforce Atlas project root. Open the .Rproj in Positron or set the working directory to the project folder.', call. = FALSE)
}

.root <- .local_project_root_runall()
.old_wd <- getwd()
on.exit(setwd(.old_wd), add = TRUE)
setwd(.root)

# Source every script required to create the complete deliverable set. The build
# script also sources the data/scoring scripts internally, but they are sourced
# here explicitly so run_all.R is self-documenting and complete.
source(file.path('R', '00_setup.R'))
message('Preparing required R packages and the editable-Excel DrawingML toolchain.')
setup_packages(install_optional = FALSE)

source(file.path('R', '01_lwda_crosswalk.R'))
source(file.path('R', '02_data_download.R'))
source(file.path('R', '03_ai_scores.R'))
source(file.path('R', '04_build_atlas.R'))
source(file.path('R', '10_iowa_report_style.R'))
source(file.path('R', '05_visualize.R'))
source(file.path('R', '07_public_visualizations.R'))
source(file.path('R', '06_render.R'))
source(file.path('R', '08_pdf_reports.R'))
source(file.path('R', '12_excel_editable_figures.R'))
source(file.path('R', '11_validate_outputs.R'))

message('Step 1/7: building atlas data.')
build_atlas(refresh = FALSE, install_optional = FALSE)

message('Step 2/7: creating core report figures.')
make_figures(refresh = FALSE)

message('Step 3/7: creating 26 public visualization figures and gallery.')
make_public_visualizations(install_missing = TRUE, build_if_missing = FALSE, refresh = FALSE)

message('Step 4/7: rendering Quarto and R Markdown HTML reports.')
render_reports(refresh = FALSE, stop_on_error = TRUE, quiet = FALSE, make_core_figures = FALSE)

message('Step 5/7: creating PDF reports and all-figures PDF compendium.')
make_pdf_reports(install_missing = TRUE, build_if_missing = FALSE, use_chrome = TRUE)

message('Step 6/7: creating editable Excel figure workbook.')
make_editable_excel_figures(install_missing = TRUE, build_if_missing = FALSE, refresh = FALSE)

message('Step 7/7: validating complete output set.')
validate_run_outputs(stop_on_missing = TRUE, expected_public_figures = 26L)

message('Done. See data_processed/, figures/, figures/public/, outputs/, and outputs/iowa_ai_workforce_atlas_editable_figures.xlsx.')
