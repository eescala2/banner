# 12_excel_editable_figures.R ----------------------------------------------
# Create an Excel workbook containing every generated Atlas figure as an
# editable Microsoft Office vector drawing. This gives non-R users a single
# Excel file where they can ungroup/edit shapes, text, colors, fonts, legends,
# and labels manually while retaining the R-generated source data sheets.

.local_project_root_excel <- function() {
  here <- normalizePath(getwd(), winslash = '/', mustWork = TRUE)
  script_dir <- tryCatch({
    frames <- sys.frames()
    ofiles <- vapply(frames, function(x) {
      val <- x$ofile
      if (is.null(val)) NA_character_ else as.character(val)
    }, character(1))
    ofiles <- stats::na.omit(ofiles)
    if (length(ofiles)) normalizePath(dirname(ofiles[[length(ofiles)]]), winslash = '/', mustWork = FALSE) else NA_character_
  }, error = function(e) NA_character_)
  candidates <- unique(stats::na.omit(c(
    here,
    dirname(here),
    normalizePath(file.path(here, '..'), winslash = '/', mustWork = FALSE),
    script_dir,
    normalizePath(file.path(script_dir, '..'), winslash = '/', mustWork = FALSE)
  )))
  for (cand in candidates) {
    if (file.exists(file.path(cand, 'config.yml')) && dir.exists(file.path(cand, 'R'))) {
      return(normalizePath(cand, winslash = '/', mustWork = TRUE))
    }
  }
  stop('Could not locate project root. Open the .Rproj in Positron or set the working directory to the project folder.', call. = FALSE)
}

.root_excel <- .local_project_root_excel()
source(file.path(.root_excel, 'R', '00_setup.R'))

.excel_required_pkgs <- c(
  'systemfonts', 'gdtools', 'officer', 'openxlsx2', 'rvg',
  'dplyr', 'tidyr', 'readr', 'stringr', 'purrr', 'tibble',
  'ggplot2', 'scales', 'fs', 'glue', 'sf', 'png'
)

install_editable_excel_packages <- function(install_missing = TRUE) {
  # The systemfonts/gdtools/rvg stack must be installed before ragg or another
  # graphics package loads an older systemfonts DLL. setup_packages() performs
  # this preflight at the beginning of run_all.R; this call is an idempotent
  # safeguard for users who run this script by itself.
  ensure_editable_excel_toolchain(install_missing = install_missing)
  install_if_missing(setdiff(.excel_required_pkgs, editable_excel_pkgs), optional = FALSE)

  still_missing <- setdiff(.excel_required_pkgs, rownames(utils::installed.packages()))
  if (length(still_missing)) {
    stop(
      'Missing required packages for the editable Excel figure workbook: ',
      paste(still_missing, collapse = ', '), '.',
      call. = FALSE
    )
  }

  failed <- character()
  for (pkg in .excel_required_pkgs) {
    ok <- suppressWarnings(suppressPackageStartupMessages(require(pkg, character.only = TRUE)))
    if (!isTRUE(ok)) failed <- c(failed, pkg)
  }
  if (length(failed)) {
    stop('Editable Excel packages could not be loaded: ', paste(failed, collapse = ', '), call. = FALSE)
  }
  invisible(TRUE)
}

# Source plotting utilities lazily after packages are available.
load_editable_excel_dependencies <- function(install_missing = TRUE) {
  install_editable_excel_packages(install_missing = install_missing)
  p <- paths()
  source(file.path(p$R, '01_lwda_crosswalk.R'))
  source(file.path(p$R, '02_data_download.R'))
  source(file.path(p$R, '03_ai_scores.R'))
  source(file.path(p$R, '04_build_atlas.R'))
  source(file.path(p$R, '10_iowa_report_style.R'))
  source(file.path(p$R, '05_visualize.R'))
  source(file.path(p$R, '07_public_visualizations.R'))
  invisible(TRUE)
}

excel_safe_sheet_name <- function(x, used = character()) {
  x <- as.character(x)
  x <- stringr::str_replace_all(x, "[\\:\\\\/\\?\\*\\[\\]\"]", '_')
  x <- stringr::str_replace_all(x, "[^A-Za-z0-9 _.-]", '_')
  x <- stringr::str_squish(x)
  if (!nzchar(x)) x <- 'Sheet'
  base <- substr(x, 1, 31)
  out <- base
  i <- 1L
  while (tolower(out) %in% tolower(used)) {
    suffix <- paste0('_', i)
    out <- paste0(substr(base, 1, 31 - nchar(suffix)), suffix)
    i <- i + 1L
  }
  out
}

excel_color <- function(hex) {
  hex <- gsub('#', '', hex)
  if (nchar(hex) == 6L) hex <- paste0('FF', hex)
  openxlsx2::wb_color(hex = hex)
}

excel_write_text <- function(wb, sheet, x, row, col = 1, font_size = 12, bold = FALSE, color = '#000000') {
  wb$add_data(sheet = sheet, x = as.data.frame(x, stringsAsFactors = FALSE), start_row = row, start_col = col, col_names = FALSE)
  dims <- openxlsx2::wb_dims(rows = row:(row + nrow(as.data.frame(x)) - 1L), cols = col:(col + ncol(as.data.frame(x)) - 1L))
  try(wb$add_font(sheet = sheet, dims = dims, name = 'Arial', size = as.character(font_size), bold = if (bold) '1' else '', color = excel_color(color)), silent = TRUE)
  invisible(wb)
}

excel_style_header <- function(wb, sheet, dims) {
  brand <- atlas_brand()
  try(wb$add_fill(sheet = sheet, dims = dims, color = excel_color(brand$blue)), silent = TRUE)
  try(wb$add_font(sheet = sheet, dims = dims, name = 'Arial', size = '11', bold = '1', color = excel_color('#FFFFFF')), silent = TRUE)
  try(wb$add_cell_style(sheet = sheet, dims = dims, horizontal = 'center', vertical = 'center', wrap_text = TRUE), silent = TRUE)
  invisible(wb)
}

excel_clean_df <- function(df, max_rows = 250000L) {
  if (is.null(df)) return(tibble::tibble())
  if (inherits(df, 'sf')) df <- sf::st_drop_geometry(df)
  df <- as.data.frame(df, stringsAsFactors = FALSE)
  if (!nrow(df) && !ncol(df)) return(tibble::tibble())
  # Excel does not handle list columns well. Convert them to character.
  for (nm in names(df)) {
    if (inherits(df[[nm]], 'POSIXct') || inherits(df[[nm]], 'POSIXlt')) df[[nm]] <- as.character(df[[nm]])
    if (inherits(df[[nm]], 'Date')) df[[nm]] <- as.character(df[[nm]])
    if (is.list(df[[nm]]) || inherits(df[[nm]], 'sfc')) df[[nm]] <- vapply(df[[nm]], function(z) paste(utils::capture.output(str(z, give.attr = FALSE, max.level = 1L)), collapse = ' '), character(1))
  }
  if (nrow(df) > max_rows) {
    df <- df[seq_len(max_rows), , drop = FALSE]
    attr(df, 'atlas_truncated') <- TRUE
  }
  tibble::as_tibble(df)
}

excel_add_data_sheet <- function(wb, sheet_name, df, used_sheets, description = NULL, max_rows = 250000L) {
  sheet_name <- excel_safe_sheet_name(sheet_name, used_sheets)
  used_sheets <- c(used_sheets, sheet_name)
  wb$add_worksheet(sheet_name)
  df <- excel_clean_df(df, max_rows = max_rows)
  brand <- atlas_brand()
  if (!is.null(description)) {
    excel_write_text(wb, sheet_name, data.frame(description = description), row = 1, col = 1, font_size = 12, color = brand$black)
    start_row <- 3L
  } else {
    start_row <- 1L
  }
  if (nrow(df) || ncol(df)) {
    table_name <- substr(gsub('[^A-Za-z0-9_]', '_', paste0('tbl_', sheet_name)), 1, 240)
    tryCatch({
      wb$add_data_table(sheet = sheet_name, x = df, start_row = start_row, start_col = 1, table_name = table_name, with_filter = TRUE)
    }, error = function(e) {
      wb$add_data(sheet = sheet_name, x = df, start_row = start_row, start_col = 1, with_filter = TRUE)
    })
    header_dims <- openxlsx2::wb_dims(rows = start_row, cols = seq_len(max(1L, ncol(df))))
    excel_style_header(wb, sheet_name, header_dims)
    try(wb$freeze_pane(sheet = sheet_name, first_row = TRUE), silent = TRUE)
    try(wb$set_col_widths(sheet = sheet_name, cols = seq_len(min(30L, ncol(df))), widths = 'auto'), silent = TRUE)
    try(wb$add_cell_style(sheet = sheet_name, dims = openxlsx2::wb_dims(rows = start_row:(start_row + min(nrow(df), 250L)), cols = seq_len(max(1L, ncol(df)))), wrap_text = TRUE, vertical = 'top'), silent = TRUE)
  } else {
    excel_write_text(wb, sheet_name, data.frame(note = 'No data were available for this source table.'), row = start_row, col = 1)
  }
  list(wb = wb, used_sheets = used_sheets, sheet_name = sheet_name)
}

excel_render_dml <- function(plot_obj, width = 12, height = 7.5) {
  tmp <- tempfile(fileext = '.xml')
  # Arial is requested by the report style. It is also a Microsoft Office-safe font.
  rvg::dml_xlsx(
    file = tmp,
    width = width,
    height = height,
    bg = 'transparent',
    fonts = list(sans = 'Arial', serif = 'Arial', mono = 'Courier New'),
    pointsize = 10,
    editable = TRUE,
    standalone = TRUE
  )
  on.exit({
    if (grDevices::dev.cur() > 1L) try(grDevices::dev.off(), silent = TRUE)
  }, add = TRUE)
  print(plot_obj)
  grDevices::dev.off()
  tmp
}

excel_add_figure_sheet <- function(wb, spec, plot_obj, used_sheets, data_sources = character(), png_reference = NULL, stop_on_error = TRUE) {
  sheet <- excel_safe_sheet_name(paste0('Fig_', spec$id, '_', spec$short), used_sheets)
  used_sheets <- c(used_sheets, sheet)
  wb$add_worksheet(sheet)
  brand <- atlas_brand()

  header <- data.frame(value = paste0('Figure ', spec$id, '. ', spec$title))
  wb$add_data(sheet = sheet, x = header, start_row = 1, start_col = 1, col_names = FALSE)
  try(wb$merge_cells(sheet = sheet, dims = 'A1:M1'), silent = TRUE)
  try(wb$add_font(sheet = sheet, dims = 'A1', name = 'Arial', size = '12', bold = '1', color = excel_color(brand$black)), silent = TRUE)
  try(wb$add_cell_style(sheet = sheet, dims = 'A1', horizontal = 'center', vertical = 'center', wrap_text = TRUE), silent = TRUE)

  meta <- data.frame(
    field = c('Primary audience', 'Editable instructions', 'Source data sheets', 'PNG reference'),
    value = c(
      spec$audience,
      'The figure below is an editable Office vector drawing. In Excel, select the graphic, right-click, choose Group > Ungroup if needed, then edit colors, fonts, labels, legends, and shapes manually.',
      paste(data_sources, collapse = ', '),
      ifelse(!is.null(png_reference) && file.exists(png_reference), normalizePath(png_reference, winslash = '/', mustWork = FALSE), 'Not available')
    ),
    stringsAsFactors = FALSE
  )
  wb$add_data(sheet = sheet, x = meta, start_row = 3, start_col = 1, with_filter = FALSE)
  try(wb$add_font(sheet = sheet, dims = 'A3:B6', name = 'Arial', size = '10', color = excel_color(brand$black)), silent = TRUE)
  try(wb$add_font(sheet = sheet, dims = 'A3:A6', name = 'Arial', size = '10', bold = '1', color = excel_color(brand$black)), silent = TRUE)
  try(wb$add_cell_style(sheet = sheet, dims = 'A3:B6', wrap_text = TRUE, vertical = 'top'), silent = TRUE)

  dml_file <- tryCatch(excel_render_dml(plot_obj, width = spec$width, height = spec$height), error = function(e) {
    if (isTRUE(stop_on_error)) stop('Could not render editable DrawingML for Figure ', spec$id, ': ', conditionMessage(e), call. = FALSE)
    warning('Could not render editable DrawingML for Figure ', spec$id, ': ', conditionMessage(e), call. = FALSE)
    NA_character_
  })
  status <- 'created_editable_drawing'
  if (!is.na(dml_file) && file.exists(dml_file)) {
    tryCatch({
      wb$add_drawing(sheet = sheet, dims = 'A8', xml = dml_file)
    }, error = function(e) {
      if (isTRUE(stop_on_error)) stop('Could not add editable DrawingML for Figure ', spec$id, ' to workbook: ', conditionMessage(e), call. = FALSE)
      warning('Could not add editable DrawingML for Figure ', spec$id, ' to workbook: ', conditionMessage(e), call. = FALSE)
      status <<- 'drawing_add_failed'
    })
  } else {
    status <- 'drawing_render_failed'
  }

  try(wb$set_col_widths(sheet = sheet, cols = 1:13, widths = c(17, rep(15, 12))), silent = TRUE)
  try(wb$set_row_heights(sheet = sheet, rows = 1, heights = 24), silent = TRUE)
  list(wb = wb, used_sheets = used_sheets, sheet_name = sheet, status = status)
}

core_figure_specs <- function() {
  list(
    list(id = 'C1', filename = 'county_automation_exposure.png', short = 'County_Automation', title = 'County automation exposure', width = 9, height = 6, audience = 'Public, policymakers, workforce boards'),
    list(id = 'C2', filename = 'county_pro_worker_opportunity.png', short = 'County_Opportunity', title = 'County pro-worker AI opportunity', width = 9, height = 6, audience = 'Public, policymakers, workforce boards'),
    list(id = 'C3', filename = 'lwda_ai_metrics.png', short = 'LWDA_Metrics', title = 'Statewide and LWDA AI transition metrics', width = 10, height = 8, audience = 'Workforce boards, policymakers'),
    list(id = 'C4', filename = 'sector_risk_opportunity_quadrant.png', short = 'Sector_Quadrant', title = 'Industry opportunity quadrant', width = 10, height = 7, audience = 'Economic developers, policymakers')
  )
}

core_plot_objects <- function(data) {
  p <- paths(); cfg <- load_config(); brand <- atlas_brand()
  county <- data$county
  lwda <- data$lwda
  sector <- data$sector
  shapes <- data$shapes
  out <- list()

  if (!is.null(shapes) && nrow(county)) {
    mapdat <- shapes |> dplyr::left_join(county, by = 'county_fips')
    out$C1 <- ggplot2::ggplot(mapdat) +
      ggplot2::geom_sf(ggplot2::aes(fill = automation_exposure), color = 'white', linewidth = 0.15) +
      atlas_color_scale_continuous(labels = atlas_axis_percent(accuracy = 1), limits = range_pad(mapdat$automation_exposure)) +
      ggplot2::labs(title = NULL, subtitle = NULL, caption = NULL, fill = 'Exposure') +
      atlas_void_theme() +
      ggplot2::theme(legend.position = 'right')

    out$C2 <- ggplot2::ggplot(mapdat) +
      ggplot2::geom_sf(ggplot2::aes(fill = pro_worker_opportunity), color = 'white', linewidth = 0.15) +
      atlas_color_scale_continuous(labels = atlas_axis_percent(accuracy = 1), limits = range_pad(mapdat$pro_worker_opportunity)) +
      ggplot2::labs(title = NULL, subtitle = NULL, caption = NULL, fill = 'Opportunity') +
      atlas_void_theme() +
      ggplot2::theme(legend.position = 'right')
  }

  if (nrow(lwda)) {
    out$C3 <- lwda |>
      tidyr::pivot_longer(c(automation_exposure, augmentation_potential, expertise_leveling_potential, new_task_opportunity, pro_worker_opportunity),
                          names_to = 'metric', values_to = 'score') |>
      dplyr::filter(is.finite(score)) |>
      dplyr::mutate(metric = stringr::str_replace_all(metric, '_', ' ') |> stringr::str_to_title()) |>
      ggplot2::ggplot(ggplot2::aes(x = score, y = stats::reorder(lwda_combined, score))) +
      ggplot2::geom_col(fill = brand$blue) +
      ggplot2::facet_wrap(~metric, ncol = 2) +
      ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
      ggplot2::labs(title = NULL, subtitle = NULL, caption = NULL, x = 'Employment-weighted score', y = NULL) +
      atlas_base_theme()
  }

  if (nrow(sector)) {
    top_sector <- sector |>
      dplyr::group_by(iowa_priority_sector) |>
      dplyr::summarise(jobs = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
      dplyr::slice_max(jobs, n = 12)
    out$C4 <- sector |>
      dplyr::semi_join(top_sector, by = 'iowa_priority_sector') |>
      dplyr::group_by(iowa_priority_sector) |>
      dplyr::summarise(
        automation_exposure = stats::weighted.mean(automation_exposure, estimated_jobs, na.rm = TRUE),
        pro_worker_opportunity = stats::weighted.mean(pro_worker_opportunity, estimated_jobs, na.rm = TRUE),
        estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
        .groups = 'drop'
      ) |>
      dplyr::filter(is.finite(automation_exposure), is.finite(pro_worker_opportunity), estimated_jobs > 0) |>
      ggplot2::ggplot(ggplot2::aes(x = automation_exposure, y = pro_worker_opportunity, size = estimated_jobs, label = iowa_priority_sector)) +
      ggplot2::geom_point(alpha = 0.78, color = brand$blue) +
      ggrepel::geom_text_repel(max.overlaps = 20, seed = 1, size = 3.2, family = atlas_font_family(), color = brand$black, box.padding = 0.4, point.padding = 0.35) +
      ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
      ggplot2::scale_y_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
      ggplot2::scale_size_area(max_size = 11, labels = atlas_jobs_number(accuracy = 1)) +
      ggplot2::labs(title = NULL, subtitle = NULL, caption = NULL, x = 'Automation exposure', y = 'Pro-worker opportunity', size = 'Estimated jobs') +
      atlas_base_theme()
  }
  out
}

public_figure_specs_for_excel <- function() {
  list(
    list(id = '01', filename = 'public_01_county_bivariate_risk_opportunity.png', short = 'Bivariate_Map', title = 'County bivariate risk-opportunity map', width = 13, height = 7.5, audience = 'Public, policymakers', fun = plot_01_county_bivariate_risk_opportunity),
    list(id = '02', filename = 'public_02_county_dominant_transition_action.png', short = 'County_Action', title = 'County dominant transition action', width = 11, height = 7, audience = 'Workforce boards, county leaders', fun = plot_02_county_dominant_transition_action),
    list(id = '03', filename = 'public_03_lwda_ai_compass.png', short = 'LWDA_Compass', title = 'LWDA AI compass', width = 13, height = 10, audience = 'Workforce boards', fun = plot_03_lwda_ai_compass),
    list(id = '04', filename = 'public_04_lwda_sector_bubble_heatmap.png', short = 'LWDA_Sector', title = 'LWDA sector bubble heatmap', width = 14, height = 8, audience = 'Economic developers', fun = plot_04_lwda_sector_bubble_heatmap),
    list(id = '05', filename = 'public_05_sector_policy_quadrant.png', short = 'Sector_Quadrant', title = 'Sector policy quadrant', width = 11.5, height = 8, audience = 'Policymakers, chambers, sector partnerships', fun = plot_05_sector_policy_quadrant),
    list(id = '06', filename = 'public_06_occupation_wage_risk_bubble.png', short = 'Wage_Risk', title = 'Occupation wage-risk bubble', width = 12, height = 8, audience = 'Training providers, employers', fun = plot_06_occupation_wage_risk_bubble),
    list(id = '07', filename = 'public_07_training_pipeline_alluvial.png', short = 'Training_Pipeline', title = 'Training pipeline alluvial', width = 15, height = 9, audience = 'Community colleges, workforce boards', fun = plot_07_training_pipeline_alluvial),
    list(id = '08', filename = 'public_08_training_priority_treemap.png', short = 'Training_Treemap', title = 'Training-priority treemap', width = 14, height = 9, audience = 'Training providers, public', fun = plot_08_training_priority_treemap),
    list(id = '09', filename = 'public_09_risk_distribution_ridges.png', short = 'Risk_Ridges', title = 'Risk-distribution ridges', width = 12, height = 8, audience = 'Analysts, policymakers', fun = plot_09_risk_distribution_ridges),
    list(id = '10', filename = 'public_10_lwda_commuting_alluvial.png', short = 'Commuting_Alluvial', title = 'LWDA commuting alluvial', width = 12, height = 8, audience = 'Regional planners', fun = plot_10_lwda_commuting_alluvial),
    list(id = '11', filename = 'public_11_county_equity_capacity_scatter.png', short = 'Equity_Capacity', title = 'County equity-capacity scatter', width = 12, height = 8, audience = 'Equity and access planners', fun = plot_11_county_equity_capacity_scatter),
    list(id = '12', filename = 'public_12_lwda_top_occupation_lollipops.png', short = 'Top_Occupations', title = 'LWDA top-occupation lollipops', width = 13, height = 11, audience = 'Community colleges, employer advisory boards', fun = plot_12_lwda_top_occupation_lollipops),
    list(id = '13', filename = 'public_13_transition_waffle.png', short = 'Transition_Waffle', title = 'Transition waffle chart', width = 11, height = 7, audience = 'Public, elected officials', fun = plot_13_transition_waffle),
    list(id = '14', filename = 'public_14_occupation_group_sector_matrix.png', short = 'Group_Sector', title = 'Occupation group-sector matrix', width = 15, height = 9, audience = 'Economic developers, employers', fun = plot_14_occupation_group_sector_matrix),
    list(id = '15', filename = 'public_15_lwda_transition_action_mix.png', short = 'Action_Mix', title = 'LWDA transition-action mix', width = 12, height = 7, audience = 'Workforce boards, policymakers', fun = plot_15_lwda_transition_share_bars),
    list(id = '16', filename = 'public_16_county_action_job_stack.png', short = 'County_Stack', title = 'County action job stack', width = 12, height = 10, audience = 'County leaders, grant writers', fun = plot_16_county_action_job_stack),
    list(id = '17', filename = 'public_17_sector_action_mix_heatmap.png', short = 'Sector_Action', title = 'Sector action-mix heatmap', width = 12.5, height = 9, audience = 'Economic developers, sector partnerships', fun = plot_17_sector_action_mix_heatmap),
    list(id = '18', filename = 'public_18_soc_task_channel_heatmap.png', short = 'SOC_Channel', title = 'SOC task-channel heatmap', width = 13, height = 9, audience = 'Policy analysts, training planners', fun = plot_18_soc_task_channel_heatmap),
    list(id = '19', filename = 'public_19_county_metric_small_multiple_map.png', short = 'County_Metrics', title = 'County metric small-multiple maps', width = 12, height = 9, audience = 'Public, policymakers', fun = plot_19_county_metric_small_multiple_map),
    list(id = '20', filename = 'public_20_training_funnel.png', short = 'Training_Funnel', title = 'Training funnel', width = 12, height = 7, audience = 'Public, workforce boards', fun = plot_20_training_funnel),
    list(id = '21', filename = 'public_21_sector_wage_risk_lens.png', short = 'Sector_Wage', title = 'Sector wage-risk lens', width = 12, height = 8, audience = 'Economic developers, chambers', fun = plot_21_sector_wage_risk_lens),
    list(id = '22', filename = 'public_22_lwda_risk_opportunity_dumbbell.png', short = 'LWDA_Dumbbell', title = 'LWDA risk-opportunity dumbbell', width = 12, height = 7, audience = 'Workforce boards, local leaders', fun = plot_22_lwda_risk_opportunity_dumbbell),
    list(id = '23', filename = 'public_23_county_wage_risk_lens.png', short = 'County_Wage', title = 'County wage-risk lens', width = 12, height = 8, audience = 'Economic developers, county leaders', fun = plot_23_county_wage_risk_lens),
    list(id = '24', filename = 'public_24_sector_channel_scorecard.png', short = 'Sector_Scorecard', title = 'Sector channel scorecard', width = 13, height = 8.5, audience = 'Economic developers, sector partnerships', fun = plot_24_sector_channel_scorecard),
    list(id = '25', filename = 'public_25_lwda_training_occ_group_heatmap.png', short = 'LWDA_Occ_Group', title = 'LWDA training occupation-group heatmap', width = 12.5, height = 8.5, audience = 'Community colleges, workforce boards', fun = plot_25_lwda_training_occ_group_heatmap),
    list(id = '26', filename = 'public_26_county_action_leaderboard.png', short = 'County_Leaderboard', title = 'County action leaderboard', width = 13, height = 9, audience = 'County leaders, grant writers, workforce boards', fun = plot_26_county_action_leaderboard)
  )
}

excel_pick_numeric <- function(df, candidates, default = NA_real_) {
  n <- if (is.null(df)) 0L else nrow(df)
  if (!n) return(numeric())
  for (nm in candidates) {
    if (nm %in% names(df)) return(suppressWarnings(as.numeric(df[[nm]])))
  }
  rep(as.numeric(default), n)
}

excel_weighted_mean <- function(x, w) {
  x <- suppressWarnings(as.numeric(x))
  w <- suppressWarnings(as.numeric(w))
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  stats::weighted.mean(x[ok], w[ok])
}

excel_build_source_tables <- function(data) {
  atlas <- data$atlas
  atlas_lwda_sector_occ <- tibble::tibble()
  if (!is.null(atlas) && nrow(atlas)) {
    # Processed atlas vintages differ slightly in whether localized opportunity
    # fields and the derived risk gap are persisted. Build stable Excel-only
    # fields without ever referring to a column that may not exist.
    atlas$excel_new_task_opportunity <- excel_pick_numeric(
      atlas, c('new_task_opportunity_local', 'new_task_opportunity')
    )
    atlas$excel_pro_worker_opportunity <- excel_pick_numeric(
      atlas, c('pro_worker_opportunity_local', 'pro_worker_opportunity')
    )
    stored_gap <- excel_pick_numeric(atlas, c('risk_opportunity_gap', 'risk_minus_opportunity'))
    calculated_gap <- excel_pick_numeric(atlas, c('automation_exposure')) - atlas$excel_pro_worker_opportunity
    atlas$excel_risk_opportunity_gap <- dplyr::coalesce(stored_gap, calculated_gap)

    atlas_lwda_sector_occ <- atlas |>
      dplyr::group_by(lwda_combined, iowa_priority_sector, soc_code, occupation_title, transition_priority) |>
      dplyr::summarise(
        automation_exposure = excel_weighted_mean(automation_exposure, estimated_jobs),
        augmentation_potential = excel_weighted_mean(augmentation_potential, estimated_jobs),
        expertise_leveling_potential = excel_weighted_mean(expertise_leveling_potential, estimated_jobs),
        new_task_opportunity = excel_weighted_mean(excel_new_task_opportunity, estimated_jobs),
        pro_worker_opportunity = excel_weighted_mean(excel_pro_worker_opportunity, estimated_jobs),
        risk_opportunity_gap = excel_weighted_mean(excel_risk_opportunity_gap, estimated_jobs),
        estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
        .groups = 'drop'
      ) |>
      dplyr::arrange(lwda_combined, dplyr::desc(estimated_jobs))
  }
  list(
    Data_County = data$county,
    Data_LWDA = data$lwda,
    Data_Sector_LWDA = data$sector,
    Data_Training = data$training,
    Data_Commuting = data$flows,
    Data_Occupation_Scores = data$occ_scores,
    Data_Atlas_Aggregated = atlas_lwda_sector_occ
  )
}

make_editable_excel_figures <- function(install_missing = TRUE, build_if_missing = TRUE, refresh = FALSE,
                                        output_file = NULL, stop_on_error = TRUE) {
  load_editable_excel_dependencies(install_missing = install_missing)
  p <- paths()
  fs::dir_create(p$outputs)
  if (is.null(output_file)) output_file <- file.path(p$outputs, 'iowa_ai_workforce_atlas_editable_figures.xlsx')

  # Ensure the data and PNG outputs exist. The workbook embeds editable vector
  # drawings, but retaining PNG outputs makes it easy to compare final styling.
  if (isTRUE(build_if_missing) && !compat_table_exists('county_industry_occupation_atlas', p$processed)) {
    build_atlas(refresh = refresh, install_optional = FALSE)
  }
  if (!file.exists(file.path(p$outputs, 'public_visualization_manifest.csv')) || isTRUE(refresh)) {
    make_public_visualizations(install_missing = install_missing, build_if_missing = build_if_missing, refresh = refresh)
  }
  data <- get_public_viz_data(build_if_missing = build_if_missing, refresh = refresh)

  wb <- openxlsx2::wb_workbook()
  used_sheets <- character()
  brand <- atlas_brand()

  # Overview and instructions.
  overview <- excel_safe_sheet_name('00_READ_ME', used_sheets); used_sheets <- c(used_sheets, overview)
  wb$add_worksheet(overview)
  read_me <- data.frame(
    field = c(
      'Purpose',
      'How to edit a figure',
      'Data sheets',
      'Regenerating figures',
      'Important limitation',
      'Package compatibility',
      'Created by'
    ),
    value = c(
      'This workbook contains every core and public Iowa AI Workforce Atlas figure as an editable Microsoft Office vector drawing inside Excel.',
      'Open a Fig_* sheet, select the graphic, right-click, and choose Group > Ungroup if Excel asks. After ungrouping, individual labels, fills, strokes, legends, and shapes can be selected and edited manually.',
      'The Data_* worksheets contain the main source tables and aggregated chart-ready tables used by the figures. They are included for review and manual reference.',
      'Changing data in this workbook will not automatically redraw the Office vector drawings. To update figures from changed data, update the project data and rerun R/run_all.R. For quick design changes, edit the shapes directly in Excel.',
      'Complex maps, treemaps, alluvial diagrams, ridgelines, and patchwork layouts are not native Excel chart types. They are stored as editable DrawingML vector objects so they can still be manually restyled in Excel.',
      paste0('DrawingML stack: openxlsx2 ', as.character(utils::packageVersion('openxlsx2')), '; rvg ', as.character(utils::packageVersion('rvg')), '; systemfonts ', as.character(utils::packageVersion('systemfonts')), '. Packages are prepared before graphics libraries load.'),
      paste0('Iowa AI Workforce Atlas, ', format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z'))
    ),
    stringsAsFactors = FALSE
  )
  wb$add_data(sheet = overview, x = read_me, start_row = 1, start_col = 1, with_filter = TRUE)
  excel_style_header(wb, overview, 'A1:B1')
  try(wb$add_font(sheet = overview, dims = 'A1:B50', name = 'Arial', size = '12', color = excel_color(brand$black)), silent = TRUE)
  try(wb$add_cell_style(sheet = overview, dims = 'A1:B50', wrap_text = TRUE, vertical = 'top'), silent = TRUE)
  try(wb$set_col_widths(sheet = overview, cols = c(1, 2), widths = c(24, 110)), silent = TRUE)
  try(wb$freeze_pane(sheet = overview, first_row = TRUE), silent = TRUE)

  # Source data sheets.
  source_tables <- excel_build_source_tables(data)
  data_sheet_lookup <- names(source_tables)
  for (nm in names(source_tables)) {
    res <- excel_add_data_sheet(
      wb, nm, source_tables[[nm]], used_sheets,
      description = paste0('Source/aggregated data used for editable Atlas figure workbook: ', nm),
      max_rows = if (identical(nm, 'Data_Atlas_Aggregated')) 1000000L else 250000L
    )
    wb <- res$wb; used_sheets <- res$used_sheets
  }

  # Build figure sheets.
  core_specs <- core_figure_specs()
  core_plots <- core_plot_objects(data)
  public_specs <- public_figure_specs_for_excel()

  figure_rows <- list()

  for (spec in core_specs) {
    plot_obj <- core_plots[[spec$id]]
    if (is.null(plot_obj)) {
      if (isTRUE(stop_on_error)) stop('Core Figure ', spec$id, ' could not be recreated for editable Excel output.', call. = FALSE)
      next
    }
    png_path <- file.path(p$figures, spec$filename)
    res <- excel_add_figure_sheet(wb, spec, plot_obj, used_sheets, data_sources = c('Data_County', 'Data_LWDA', 'Data_Sector_LWDA'), png_reference = png_path, stop_on_error = stop_on_error)
    wb <- res$wb; used_sheets <- res$used_sheets
    figure_rows[[length(figure_rows) + 1L]] <- tibble::tibble(id = spec$id, figure = spec$title, sheet = res$sheet_name, status = res$status, png = png_path, source_data = paste(c('Data_County', 'Data_LWDA', 'Data_Sector_LWDA'), collapse = ', '))
  }

  for (spec in public_specs) {
    plot_obj <- tryCatch(spec$fun(data), error = function(e) {
      if (isTRUE(stop_on_error)) stop('Public Figure ', spec$id, ' could not be recreated for editable Excel output: ', conditionMessage(e), call. = FALSE)
      warning('Public Figure ', spec$id, ' could not be recreated for editable Excel output: ', conditionMessage(e), call. = FALSE)
      NULL
    })
    if (is.null(plot_obj)) next
    png_path <- file.path(p$figures, 'public', spec$filename)
    data_sources <- c(
      'Data_County', 'Data_LWDA', 'Data_Sector_LWDA', 'Data_Training',
      'Data_Commuting', 'Data_Occupation_Scores', 'Data_Atlas_Aggregated'
    )
    res <- excel_add_figure_sheet(wb, spec, plot_obj, used_sheets, data_sources = data_sources, png_reference = png_path, stop_on_error = stop_on_error)
    wb <- res$wb; used_sheets <- res$used_sheets
    figure_rows[[length(figure_rows) + 1L]] <- tibble::tibble(id = spec$id, figure = spec$title, sheet = res$sheet_name, status = res$status, png = png_path, source_data = paste(data_sources, collapse = ', '))
  }

  manifest <- dplyr::bind_rows(figure_rows) |>
    dplyr::mutate(created_at = format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z'))

  index_sheet <- excel_safe_sheet_name('Figure_Index', used_sheets); used_sheets <- c(used_sheets, index_sheet)
  wb$add_worksheet(index_sheet)
  wb$add_data_table(sheet = index_sheet, x = manifest, start_row = 1, start_col = 1, table_name = 'EditableFigureIndex', with_filter = TRUE)
  excel_style_header(wb, index_sheet, openxlsx2::wb_dims(rows = 1, cols = seq_len(ncol(manifest))))
  try(wb$add_font(sheet = index_sheet, dims = openxlsx2::wb_dims(rows = 1:(nrow(manifest) + 1L), cols = seq_len(ncol(manifest))), name = 'Arial', size = '10', color = excel_color(brand$black)), silent = TRUE)
  try(wb$add_cell_style(sheet = index_sheet, dims = openxlsx2::wb_dims(rows = 1:(nrow(manifest) + 1L), cols = seq_len(ncol(manifest))), wrap_text = TRUE, vertical = 'top'), silent = TRUE)
  try(wb$set_col_widths(sheet = index_sheet, cols = seq_len(ncol(manifest)), widths = 'auto'), silent = TRUE)
  try(wb$freeze_pane(sheet = index_sheet, first_row = TRUE), silent = TRUE)

  # Save manifest alongside the workbook for automated validation.
  readr::write_csv(manifest, file.path(p$outputs, 'editable_excel_figure_manifest.csv'))

  openxlsx2::wb_save(wb, file = output_file, overwrite = TRUE)
  message('Wrote editable Excel figure workbook: ', normalizePath(output_file, winslash = '/', mustWork = FALSE))
  invisible(output_file)
}

if (sys.nframe() == 0) {
  make_editable_excel_figures(install_missing = TRUE, build_if_missing = TRUE, refresh = FALSE)
}
