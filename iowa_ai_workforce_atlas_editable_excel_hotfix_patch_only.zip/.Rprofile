# Project startup settings for Positron/R 4.4.0 "Puppy Cup" and newer.
# Users can override the repository with IA_ATLAS_CRAN_REPO and the private
# package library with IA_ATLAS_R_LIB.
repo <- Sys.getenv('IA_ATLAS_CRAN_REPO', unset = '')
if (!nzchar(repo)) repo <- 'https://packagemanager.posit.co/cran/latest'
repos <- getOption('repos')
current <- tryCatch(repos[['CRAN']], error = function(e) NA_character_)
if (is.null(repos) || is.na(current) || identical(current, '@CRAN@') || !nzchar(current)) {
  options(repos = c(CRAN = repo))
}
options(download.file.method = 'libcurl')
options(tigris_use_cache = TRUE)

# Keep the Excel DrawingML dependency stack in a user-local library rather than
# replacing DLLs inside C:/R-4.4.0/library. This avoids Windows permission and
# file-lock failures when systemfonts is upgraded for rvg.
r_tag <- paste0('R-', R.version[['major']], '.', strsplit(R.version[['minor']], '.', fixed = TRUE)[[1L]][1L])
lib_override <- Sys.getenv('IA_ATLAS_R_LIB', unset = '')
if (nzchar(lib_override)) {
  atlas_lib <- normalizePath(path.expand(lib_override), winslash = '/', mustWork = FALSE)
} else if (.Platform$OS.type == 'windows') {
  local_base <- Sys.getenv('LOCALAPPDATA', unset = '')
  if (!nzchar(local_base)) local_base <- file.path(path.expand('~'), 'AppData', 'Local')
  atlas_lib <- normalizePath(file.path(local_base, 'IowaAIWorkforceAtlas', 'library', r_tag), winslash = '/', mustWork = FALSE)
} else {
  atlas_lib <- normalizePath(file.path(path.expand('~'), '.local', 'share', 'IowaAIWorkforceAtlas', 'library', r_tag), winslash = '/', mustWork = FALSE)
}
dir.create(atlas_lib, recursive = TRUE, showWarnings = FALSE)
.libPaths(unique(c(atlas_lib, .libPaths())))
options(ia_atlas_package_library = atlas_lib)

# Prefer binary packages on Windows/macOS; this avoids source compilation issues in R 4.4.x.
if (.Platform$OS.type == 'windows' || identical(Sys.info()[['sysname']], 'Darwin')) {
  options(pkgType = 'binary')
}
