# Positron + R 4.4.0 “Puppy Cup” compatibility notes

This package is the same Iowa AI Workforce Atlas workflow, adjusted to run cleanly in Positron with R 4.4.0 “Puppy Cup” and newer R releases.

## What stayed the same

The analytic workflow, data sources, outputs, figures, reports, and PDF-generation capabilities are unchanged:

- local BLS OEWS workbook support for `state_M2025_dl.xlsx` and `all_data_M_2025.xlsx`;
- BLS National Employment Matrix parsing;
- O*NET task scoring;
- AIOE optional benchmark download;
- QWI with LODES WAC fallback;
- ACS county demographics;
- combined Mississippi Valley + South Central LWDA geography;
- 26 public visualizations;
- Quarto HTML and R Markdown HTML reports;
- Quarto PDF, R Markdown PDF, and all-generated-figures PDF compendium;
- WCAG-oriented print/readability improvements and the PDF accessibility checklist.

## Compatibility changes made

1. `R/00_setup.R` now explicitly targets R >= 4.4.0 and prints the detected R version at startup.
2. Package installation no longer calls `glue::glue()` before the `glue` package is installed, which could fail on a fresh Puppy Cup setup.
3. The default repository is now Posit Package Manager (`https://packagemanager.posit.co/cran/latest`) unless the user sets `IA_ATLAS_CRAN_REPO`.
4. Package installation uses `libcurl`, parallel installs when possible, and a CRAN fallback if the configured repository fails.
5. `run_all.R` and `R/run_all.R` now discover the project root before sourcing other scripts, so they work whether Positron sources from the project root or from inside the `R/` folder.
6. `R/06_render.R` now checks for Quarto CLI availability in a way that works across older and newer versions of the `quarto` R package.
7. `R/07_public_visualizations.R` and `R/08_pdf_reports.R` use the same Positron-friendly repository and installation behavior for visualization/PDF-only dependencies.
8. `.Rprofile` sets project-local repository, `libcurl`, and TIGER/Line caching defaults.
9. `R/09_positron_r44_check.R` was added as an optional diagnostic script. It does not change the atlas outputs.

No scoring, allocation, map, visualization, report, or PDF content logic was changed for compatibility.

## Recommended Positron workflow

1. Open `iowa-ai-workforce-atlas.Rproj` in Positron.
2. Confirm the R console says R 4.4.0 “Puppy Cup” or newer.
3. Run:

```r
source("R/run_all.R")
```

The project will produce the same output folders:

```text
data_processed/
figures/
figures/public/
outputs/
```

## Optional environment check

Run this if you want a package/Quarto/Chrome diagnostic before or after the workflow:

```r
source("R/09_positron_r44_check.R")
positron_r44_environment_check(write_outputs = TRUE)
```

It writes:

```text
outputs/positron_r44_environment_check.csv
```

## Optional Chrome path for PDF printing

If Positron cannot find Chrome for HTML-to-PDF printing, set this before running the PDF step:

```r
Sys.setenv(
  PAGEDOWN_CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
)
```

If Chrome is unavailable, `R/08_pdf_reports.R` still creates the R-only landscape figure compendium PDF.

## Repository override

For a locked institutional CRAN mirror or Posit Package Manager snapshot, set:

```r
Sys.setenv(IA_ATLAS_CRAN_REPO = "https://packagemanager.posit.co/cran/latest")
```

Then run `source("R/run_all.R")`.


## R 4.4 / Positron package-install hotfix

This version treats `arrow` and `duckdb` as optional rather than required. In some R 4.4.0 Puppy Cup / Windows / Positron environments, installing `arrow` can also attempt optional dependencies such as `duckdb` and `withr`; if those source/binary installs fail, the previous package stopped before the atlas could build.

The analytical workflow no longer requires those packages. When `arrow` is installed, the project writes the same Parquet files as before. When `arrow` is not installed, it writes and reads the same atlas data from:

```text
data_processed/county_industry_occupation_atlas.rds
data_processed/county_industry_occupation_atlas.csv.gz
data_processed/occupation_ai_scores.rds
data_processed/occupation_ai_scores.csv.gz
```

All reports, figures, public visualizations, HTML outputs, and PDF outputs retain the same functionality. The only compatibility change is the storage backend used for the large atlas table when Parquet support is unavailable.

The setup script also prefers binary packages on Windows and macOS and avoids installing heavy `Suggests` dependencies by default.

## Editable Excel dependency isolation

For the editable Excel figure workbook, `systemfonts`, `gdtools`, `officer`, `rvg`, and `openxlsx2` are prepared before graphics packages load. On Windows they are installed in a user-local Atlas package library under `%LOCALAPPDATA%/IowaAIWorkforceAtlas/library/R-4.4` by default, avoiding permission-denied errors in `C:/R-4.4.0/library` and avoiding replacement of an already-loaded DLL. The path can be overridden with `IA_ATLAS_R_LIB`.
