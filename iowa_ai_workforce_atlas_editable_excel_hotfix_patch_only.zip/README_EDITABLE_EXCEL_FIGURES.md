# Editable Excel figure workbook

The project now creates a Microsoft Excel workbook containing every generated Atlas figure as an editable Office vector drawing.

Output:

```text
outputs/iowa_ai_workforce_atlas_editable_figures.xlsx
outputs/editable_excel_figure_manifest.csv
```

The workbook includes:

- `00_READ_ME`: editing instructions for non-R users.
- `Figure_Index`: one row per editable figure sheet.
- `Data_*` sheets: county, LWDA, sector, training, commuting, occupation-score, and aggregated atlas data used by the figures.
- `Fig_*` sheets: each core report figure and each public visualization as an editable DrawingML object.

To edit a figure in Excel:

1. Open a `Fig_*` sheet.
2. Select the figure.
3. Right-click and choose **Group > Ungroup** if Excel prompts you.
4. Edit colors, fonts, line weights, legends, labels, and shapes manually.

Important note: complex R graphics such as maps, alluvial charts, treemaps, ridgelines, and patchwork layouts are not native Excel chart types. The workbook uses editable Office vector drawings so the visual elements can be manually modified in Excel. Changing the data sheets will not automatically redraw the vector figure; rerun `source("R/run_all.R")` to regenerate from changed source data.

Run only the Excel workbook step after the data/figures already exist:

```r
source("R/12_excel_editable_figures.R")
make_editable_excel_figures(
  install_missing = TRUE,
  build_if_missing = FALSE,
  refresh = FALSE
)
```

The full workflow now calls this automatically before final validation.

## Positron / R 4.4 dependency note

The workbook uses `rvg` DrawingML output, which depends on a current `systemfonts`/`gdtools` stack. The project now prepares these packages at startup in a user-local package library before any graphics packages load. After applying this update to a session that already failed with a loaded `systemfonts` DLL, restart R once before rerunning. See `README_EDITABLE_EXCEL_HOTFIX.md`.

Fast Excel-only recovery after the rest of the workflow is already complete:

```r
source("R/99_make_editable_excel_only.R")
```
